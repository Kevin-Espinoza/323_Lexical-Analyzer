#pragma once
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// multi-dimensional array to keep track of keywords
char KEYWORDS[21][10] = { "int", "float", "bool", "True", "False", "if",
						  "else", "then","endif", "endelse",
						  "while", "whileend", "do", "enddo", "for", "endfor",
						  "STDinput","STDoutput", "and", "or", "not" };
char SEPARATORS[] = ",':;()[]{}";
char OPERATORS[] = "*+-=/><%";