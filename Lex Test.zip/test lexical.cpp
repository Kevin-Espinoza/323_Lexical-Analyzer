#include "Tokens.h";

// initial conditions for bool; to determine if operator and separator are present
bool inOperator = false;
bool inSeparator = false;


ifstream filein;		
ofstream output;

char getschar;	// gets ever character within the text file
char charbuffer[25];
int b,x = 0;
bool checkComment = false;	//check if it is comments
char scanComment[2] = { '\0' };	

// setting up the default FSM States
bool endIdentifier = false;
bool endNum = false;
bool endReal = false;
bool endSep = false;
bool endOpe = false;

int setIndex = 0;	//sets the initial index for functions

bool findKeyword(char charbuffer[]) {
	for (int k = 0; k < 11; k++)
	{
		if (strcmp(KEYWORDS[k], charbuffer) == 0)
			return true;
	}
	return false;
}

bool findSeparator(char getChar) {
	for (int s = 0; s < 11; s++)
	{
		if (getChar == SEPARATORS[s])
			return true;
	}
	return false;
}


bool findOperator(char getChar) {
	for (int o = 1; o < 11; o++)
	{
		if (getChar == OPERATORS[o])
			return true;
	}
	return false;
}

bool findNumber(char charbuffer[]) {
	for (int n = 0; n <= (setIndex - 1); n++) {
		if (!isdigit(charbuffer[n])) {
			return false;
		}
	}
	return true;
}

bool findReal(char charbuffer[]) {
	string str(charbuffer);
	string substr("."); // decimal point in numbers

	size_t position = str.find(substr); // finds the decimal in sub string
	if (position != string::npos)
	{
		for (int x = 1; x < position; x++)
		{
			return false;
		}
		for (int q = position + 1; q < setIndex; q++) // loop to determine if the digit is present
		{
			if (!isdigit(charbuffer[q]))
			{
				return false;
			}
		}
		return true;

	}
	else
		return false;
}

void getText();
void lexer();


int main() {
	string file;
	string outputFileName;
	cout << "Enter the file name that is to be read. Be sure to place '.txt' at the end of file name" << endl;
	cin >> file;

	cout << "Enter the output file name where it will be written to (Does not need '.txt' at the end of name)" << endl;
	cin >> outputFileName;


	filein.open(file);
	output.open(outputFileName);

	if (!filein.is_open()) {
		cout << "There was an error when opening the file.";
		exit(0);
	}
	cout << "TOKENS               Lexemes" << endl; 
	output << "TOKENS               Lexemes" << endl;

	while (!filein.eof()) {
		getschar = filein.get();
		lexer();
	}

	return 0;
}


void getText() {

	if (endIdentifier) {
		cout << "IDENTIFIER      =     " << charbuffer << endl;
		output << "IDENTIFIER      =     " << charbuffer << endl;
		endIdentifier = false;
	}

	if (endNum) {
		cout << "NUMBER          =     " << charbuffer << endl;
		output << "NUMBER          =     " << charbuffer << endl;

		endNum = false;
	}

	if (endReal) {
		cout << "REAL            =     " << charbuffer << endl;
		output << "REAL            =     " << charbuffer << endl;
		endReal = false;
	}

	if (endSep) {	
		cout << "SEPARATOR       =     " << getschar << endl;
		output << "SEPARATOR       =     " << getschar << endl;
		endSep = false;
		inSeparator = false;
	}

	if (endOpe) { 
		cout << "OPERATOR        =     " << getschar << endl;
		output << "OPERATOR        =     " << getschar << endl;
		endOpe = false;
		inOperator = false;
	}
}

void lexer() {

	if (getschar == '!') {	
		scanComment[x] = getschar;
		x++;
		if (scanComment[1] == getschar) {
			checkComment = false;
			x = 0;
			scanComment[0] = '\0';
			scanComment[1] = '\0';
		}
		else
			checkComment = true;
	}
	if (!checkComment) {


		if (findOperator(getschar)) {
			inOperator = true;
			endOpe = true;
		}

		if (findSeparator(getschar)) {
			inSeparator = true;
			endSep = true;
		}


		if (isalnum(getschar) || getschar == '$' || getschar == '.') {
			charbuffer[b++] = getschar;		
			setIndex++;
		}
		else if ((getschar == ' ' || getschar == '\n' || inOperator || inSeparator || filein.eof()) && (b != 0)) {	
			charbuffer[b] = '\0';	
			b = 0;	
			if (findKeyword(charbuffer)) {	
				cout << "KEYWORD         =     " << charbuffer << endl;
				output << "KEYWORD         =     " << charbuffer << endl;
			}
			else if (findReal(charbuffer))	
				endReal = true;
			else if (findNumber(charbuffer)) 
				endNum = true;
			else {	
				if (!isdigit(charbuffer[0]))	
					endIdentifier = true;
			}

			setIndex = 0;	
		}
		getText();
	}
}